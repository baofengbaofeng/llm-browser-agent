# LLM Browser Agent

基于大语言模型的智能浏览器自动化代理系统，支持通过自然语言指令控制浏览器完成复杂任务。

## 系统概述

LLM Browser Agent 是一个异步 Web 应用，结合了大语言模型（LLM）的智能决策能力和浏览器自动化技术，使用户能够通过简单的自然语言描述，让 AI 自动执行网页浏览、数据提取、表单填写等复杂操作。

### 核心特性

- **自然语言任务描述**：用户只需描述任务目标，AI 自动规划执行步骤
- **浏览器自动化**：基于 browser-use 库实现智能浏览器控制
- **多语言支持**：内置 8 种语言界面（中、英、日、法、西、葡、俄、繁中）
- **实时任务监控**：通过 SSE 实时推送任务执行日志和状态
- **可配置参数**：支持模型参数、浏览器设置、代理行为的灵活配置
- **异步架构**：基于 Tornado 和 Tortoise ORM 的全异步实现

## 技术栈

| 层级 | 技术选型 |
|------|----------|
| **Web 框架** | Tornado (异步) |
| **ORM** | Tortoise ORM (异步) |
| **数据库** | MySQL 8.0+ |
| **浏览器自动化** | browser-use |
| **配置管理** | TOML |
| **前端** | Bootstrap + 原生 JavaScript |

## 项目结构

```
llm_browser_agent/
├── app.py                      # 应用入口
├── configs/
│   ├── application.toml        # 主配置文件
│   └── loader.py               # 配置加载器
├── apps/
│   ├── agent/                  # 智能体核心模块
│   │   ├── agent.py            # 任务管理
│   │   ├── agent_browser.py    # 浏览器管理
│   │   ├── agent_configuration.py
│   │   ├── agent_error.py
│   │   ├── agent_event.py
│   │   ├── agent_event_queue.py
│   │   ├── agent_event_store.py
│   │   └── agent_workspace.py
│   ├── config/                 # 配置管理模块
│   │   ├── config.py
│   │   └── apps.py
│   └── i18n/                   # 国际化模块
│       ├── lang_*.toml         # 多语言文件
│       └── language.py
├── core/
│   ├── database/               # 数据库层
│   │   ├── engine.py
│   │   └── session.py
│   ├── handlers/               # HTTP 处理器
│   │   ├── agent.py
│   │   └── config.py
│   └── middleware/             # 中间件
│       └── customer.py
├── models/                     # 数据模型
│   ├── base.py
│   ├── task.py
│   └── customer.py
├── deployments/
│   └── ddl/
│       └── database.sql        # 数据库建表脚本
├── static/                     # 静态资源
│   ├── css/
│   └── js/
├── templates/                  # HTML 模板
│   └── agent/
├── utils/                      # 工具模块
│   └── load_toml_util.py
└── tests/                      # 测试
```

## 快速开始

### 环境要求

- Python 3.11+
- MySQL 8.0+
- Chrome/Chromium 浏览器

### 安装依赖

```bash
pip install "tortoise-orm[asyncmy]" tornado browser-use
```

### 数据库配置

1. 创建数据库：
```sql
CREATE DATABASE test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

2. 执行建表脚本：
```bash
mysql -u baofengbaofeng -p test < deployments/ddl/database.sql
```

### 配置文件

编辑 `configs/application.toml`：

```toml
# Server Configuration
llm_browser_agent.server.debug = true
llm_browser_agent.server.port = 8080

# Database Configuration
llm_browser_agent.database.url = "mysql://username:password@localhost:3306/test"

# Model Configuration
llm_browser_agent.model.name = "gpt-4"
llm_browser_agent.model.temperature = 0.1
llm_browser_agent.model.api_url = "https://api.openai.com/v1"
llm_browser_agent.model.api_key = "your-api-key"

# Browser Configuration
llm_browser_agent.browser.headless = true
llm_browser_agent.browser.enable_security = true
llm_browser_agent.browser.use_sandbox = true
```

### 启动服务

```bash
python app.py
```

访问 http://localhost:8080

## API 接口

### 任务管理

| 接口 | 方法 | 描述 |
|------|------|------|
| `/api/task/submit/` | POST | 提交新任务 |
| `/api/task/{task_id}/status/` | GET | 查询任务状态 |
| `/api/task/{task_id}/cancel/` | POST | 取消任务 |
| `/api/task/{task_id}/stream/` | GET | SSE 实时日志流 |

### 配置管理

| 接口 | 方法 | 描述 |
|------|------|------|
| `/api/config/` | GET | 获取所有配置 |
| `/api/config/model/` | GET | 获取模型配置 |
| `/api/config/agent/` | GET | 获取代理配置 |
| `/api/config/browser/` | GET | 获取浏览器配置 |

## 数据库模型

### llm_browser_agent_task

存储任务执行记录和完整配置快照：

| 字段 | 类型 | 描述 |
|------|------|------|
| id | BIGINT UNSIGNED | 主键，自增 |
| task_prompt | TEXT | 任务描述 |
| status | VARCHAR(20) | 任务状态 |
| model_name | VARCHAR(100) | LLM 模型名称 |
| model_temperature | DECIMAL(2,1) | 温度参数 |
| agent_use_vision | TINYINT(1) | 是否启用视觉 |
| agent_max_actions_per_step | INT UNSIGNED | 单步最大操作数 |
| browser_headless | TINYINT(1) | 无头模式 |
| created_at | TIMESTAMP | 创建时间 |
| updated_at | TIMESTAMP | 更新时间 |

### llm_browser_agent_customer

存储客户默认配置：

| 字段 | 类型 | 描述 |
|------|------|------|
| id | BIGINT UNSIGNED | 主键 |
| customer_id | VARCHAR(255) | 客户唯一标识 |
| model_name | VARCHAR(100) | 默认模型 |
| model_api_key | VARCHAR(255) | API 密钥 |
| ... | ... | 其他配置字段 |

## 配置说明

### 模型配置

```toml
[llm_browser_agent.model]
name = "gpt-4"              # 模型名称
temperature = 0.1           # 温度参数 (0.1-1.0)
api_url = "..."             # API 地址
api_key = "..."             # API 密钥
```

### 代理配置

```toml
[llm_browser_agent.agent]
llm_timeout = 300           # LLM 请求超时(秒)
max_actions_per_step = 10   # 单步最大操作数
max_failures = 5            # 最大失败重试次数
step_timeout = 180          # 步骤超时(秒)
use_vision = false          # 是否使用视觉能力
calculate_cost = true       # 是否计算成本
```

### 浏览器配置

```toml
[llm_browser_agent.browser]
headless = true             # 无头模式
enable_security = true      # 启用安全设置
use_sandbox = true          # 使用沙箱

[llm_browser_agent.browser.window]
width = 1440                # 窗口宽度
height = 900                # 窗口高度
```

## 开发规范

### 代码风格

- 遵循 Google Python Style Guide
- 使用 4 空格缩进
- 最大行长度 100 字符
- 使用类型注解

### 提交规范

```
feat: 新功能
fix: 修复
refactor: 重构
docs: 文档
chore: 构建/配置
```

## 许可证

MIT License
